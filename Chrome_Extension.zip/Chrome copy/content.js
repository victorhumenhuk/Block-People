/* --------------------------------------------------------
 * Block People & Keywords — Content Script
 * Scans page text and media, then redacts or hides matches.
 * ------------------------------------------------------ */

const DEFAULTS = {
  blockedTerms: [],
  redactMatches: true,
  hideElements: true,
};

const storage = chrome.storage.local;

/* ---------- Selectors ---------- */

const CONTAINER_SELECTORS = [
  /* YouTube */
  "ytd-rich-item-renderer",
  "ytd-video-renderer",
  "ytd-grid-video-renderer",
  "ytd-compact-video-renderer",
  "ytd-playlist-video-renderer",
  "ytd-reel-item-renderer",
  "ytm-video-with-context-renderer",
  /* Google */
  "g-card",
  "g-inner-card",
  "div[data-hveid]",
  "div.MjjYud",
  "div.Gx5Zad",
  /* Generic */
  "article",
  "[role='article']",
  "li",
  "tr",
  "[data-testid='tweet']",
  "[data-testid='cellInnerDiv']",
  ".post",
  ".feed-item",
  ".card",
].join(", ");

const MEDIA_SELECTOR =
  "img, picture, video, canvas, svg, g-img, ytd-thumbnail, ytm-thumbnail-overlay";

const MEDIA_WRAPPER_SELECTOR = [
  "ytd-rich-item-renderer",
  "ytd-video-renderer",
  "ytd-grid-video-renderer",
  "ytd-compact-video-renderer",
  "ytd-playlist-video-renderer",
  "ytd-reel-item-renderer",
  "ytm-video-with-context-renderer",
  "g-card",
  "g-inner-card",
  "a",
  "figure",
  "picture",
  "li",
  "article",
  "section",
  "div",
].join(", ");

const GOOGLE_CONTENT_SELECTOR = [
  "#search",
  "#rhs",
  ".kp-wholepage",
  ".MjjYud",
  ".Gx5Zad",
  "g-card",
  "g-inner-card",
  "div[data-hveid]",
].join(", ");

const BLOCK_DISPLAYS = new Set([
  "block",
  "flex",
  "grid",
  "list-item",
  "table",
  "table-row",
  "table-cell",
]);

const SKIP_TAGS = new Set([
  "SCRIPT",
  "STYLE",
  "NOSCRIPT",
  "TEXTAREA",
  "INPUT",
  "OPTION",
]);

const BLOCKED_SELECTOR =
  "[data-word-blocker-hidden='1'], [data-word-blocker-redacted='1']";

const SIGNAL_ATTRS = [
  "alt",
  "aria-label",
  "title",
  "data-title",
  "data-content-feature",
  "data-src",
  "src",
];

/* ---------- State ---------- */

let settings = { ...DEFAULTS };
let matcher = null;
let applying = false;
let timer = null;

const originalText = new WeakMap();
const hiddenEls = new Set();
const originalDisplay = new WeakMap();
const redactedEls = new Set();
const originalFilter = new WeakMap();

/* ---------- Utilities ---------- */

function escapeRe(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function buildMatcher(terms) {
  if (!terms.length) return null;
  const sorted = [...terms].sort((a, b) => b.length - a.length);
  return new RegExp(sorted.map(escapeRe).join("|"), "gi");
}

function mask(s) {
  return s.replace(/\S/g, "\u2588");
}

function hasMatch(text) {
  if (!matcher || !text) return false;
  matcher.lastIndex = 0;
  return matcher.test(text);
}

function redactString(text) {
  if (!matcher || !text) return { text, matched: false };
  let matched = false;
  matcher.lastIndex = 0;
  const out = text.replace(matcher, (m) => {
    matched = true;
    return mask(m);
  });
  return { text: matched ? out : text, matched };
}

/* ---------- Settings ---------- */

function normalizeTerms(terms) {
  if (!Array.isArray(terms)) return [];
  const out = [];
  const seen = new Set();
  for (const v of terms) {
    const t = String(v).trim();
    if (!t) continue;
    const k = t.toLowerCase();
    if (seen.has(k)) continue;
    seen.add(k);
    out.push(t);
  }
  return out;
}

function normalize(raw) {
  return {
    blockedTerms: normalizeTerms(raw.blockedTerms),
    redactMatches:
      typeof raw.redactMatches === "boolean"
        ? raw.redactMatches
        : DEFAULTS.redactMatches,
    hideElements:
      typeof raw.hideElements === "boolean"
        ? raw.hideElements
        : DEFAULTS.hideElements,
  };
}

function hasUserConfig(s) {
  return (
    s.blockedTerms.length > 0 ||
    s.redactMatches !== DEFAULTS.redactMatches ||
    s.hideElements !== DEFAULTS.hideElements
  );
}

function applySettings(next) {
  settings = normalize(next);
  matcher = buildMatcher(settings.blockedTerms);
  scheduleApply();
}

/* ---------- DOM helpers ---------- */

function isTooLarge(el) {
  const r = el.getBoundingClientRect();
  if (!r || !Number.isFinite(r.width) || !Number.isFinite(r.height)) return false;
  const vw = window.innerWidth || document.documentElement.clientWidth || 0;
  const vh = window.innerHeight || document.documentElement.clientHeight || 0;
  if (!vw || !vh) return false;
  return r.width > vw * 0.96 && r.height > vh * 0.8;
}

function countMedia(el) {
  if (!el || !(el instanceof Element)) return 0;
  let n = el.matches(MEDIA_SELECTOR) ? 1 : 0;
  n += el.querySelectorAll(MEDIA_SELECTOR).length;
  return n;
}

function scoreContainer(el) {
  if (!el || el === document.body || el === document.documentElement) return -1;
  if (isTooLarge(el)) return -1;

  const style = getComputedStyle(el);
  const display = BLOCK_DISPLAYS.has(style.display) ? 14 : 0;
  const media = countMedia(el);
  const mediaScore = media > 0 ? 55 + Math.min(media, 4) * 8 : 0;
  const textLen = (el.innerText || "").trim().length;
  const textScore = Math.min(textLen, 300) / 10;
  const children = el.children.length >= 2 ? 8 : 0;
  const semantic = el.matches(CONTAINER_SELECTORS) ? 100 : 0;

  return semantic + display + mediaScore + textScore + children;
}

function findContainer(textNode) {
  const parent = textNode.parentElement;
  if (!parent) return null;

  const preferred = parent.closest(CONTAINER_SELECTORS);
  if (preferred && !isTooLarge(preferred)) return preferred;

  let el = parent;
  let best = null;
  let bestScore = -1;

  for (let depth = 0; el && el !== document.body && depth < 12; depth++) {
    const s = scoreContainer(el);
    if (s > bestScore) {
      bestScore = s;
      best = el;
    }
    el = el.parentElement;
  }

  return best && bestScore >= 20 ? best : parent;
}

/* ---------- Hide / Redact ---------- */

function hideElement(el) {
  if (!el || hiddenEls.has(el)) return false;
  originalDisplay.set(el, {
    value: el.style.getPropertyValue("display"),
    priority: el.style.getPropertyPriority("display"),
  });
  el.style.setProperty("display", "none", "important");
  el.setAttribute("data-word-blocker-hidden", "1");
  hiddenEls.add(el);
  return true;
}

function redactElement(el) {
  if (!el || redactedEls.has(el)) return false;
  originalFilter.set(el, {
    value: el.style.getPropertyValue("filter"),
    priority: el.style.getPropertyPriority("filter"),
  });
  el.style.setProperty("filter", "blur(10px) saturate(0.25)", "important");
  el.setAttribute("data-word-blocker-redacted", "1");
  redactedEls.add(el);
  return true;
}

function restoreHidden() {
  for (const el of hiddenEls) {
    const orig = originalDisplay.get(el);
    if (orig?.value) {
      el.style.setProperty("display", orig.value, orig.priority);
    } else {
      el.style.removeProperty("display");
    }
    el.removeAttribute("data-word-blocker-hidden");
  }
  hiddenEls.clear();
}

function restoreRedacted() {
  for (const el of redactedEls) {
    const orig = originalFilter.get(el);
    if (orig?.value) {
      el.style.setProperty("filter", orig.value, orig.priority);
    } else {
      el.style.removeProperty("filter");
    }
    el.removeAttribute("data-word-blocker-redacted");
  }
  redactedEls.clear();
}

/* ---------- Text processing ---------- */

function shouldSkip(node) {
  if (!(node instanceof Text) || !node.isConnected) return true;
  const p = node.parentElement;
  if (!p) return true;
  if (SKIP_TAGS.has(p.tagName)) return true;
  if (p.isContentEditable) return true;
  if (p.closest(BLOCKED_SELECTOR)) return true;
  return false;
}

function remember(node) {
  if (!originalText.has(node)) originalText.set(node, node.nodeValue || "");
}

function walkText(root, fn) {
  if (!root) return;
  if (root.nodeType === Node.TEXT_NODE) {
    fn(root);
    return;
  }
  if (root.nodeType !== Node.ELEMENT_NODE && root.nodeType !== Node.DOCUMENT_NODE) {
    return;
  }
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  let cur = walker.nextNode();
  while (cur) {
    fn(cur);
    cur = walker.nextNode();
  }
}

function shouldRedactContainer(c) {
  if (!c || !(c instanceof Element) || isTooLarge(c)) return false;
  if (c.matches(CONTAINER_SELECTORS)) return true;
  const style = getComputedStyle(c);
  return BLOCK_DISPLAYS.has(style.display) && c.children.length > 1;
}

function processTextNode(node) {
  if (shouldSkip(node)) return;
  remember(node);

  const orig = originalText.get(node) || "";

  if (!matcher) {
    if (node.nodeValue !== orig) node.nodeValue = orig;
    return;
  }

  if (!hasMatch(orig)) {
    if (node.nodeValue !== orig) node.nodeValue = orig;
    return;
  }

  const container = findContainer(node);
  const media = findNearbyMedia(node, container);

  if (settings.hideElements) {
    hideElement(container);
    for (const t of media) hideElement(t);
    if (node.nodeValue !== orig) node.nodeValue = orig;
    return;
  }

  if (settings.redactMatches) {
    if (shouldRedactContainer(container)) redactElement(container);
    for (const t of media) redactElement(t);

    if (shouldRedactContainer(container) && redactedEls.has(container)) {
      if (node.nodeValue !== orig) node.nodeValue = orig;
      return;
    }

    const result = redactString(orig);
    if (node.nodeValue !== result.text) node.nodeValue = result.text;
    return;
  }

  if (node.nodeValue !== orig) node.nodeValue = orig;
}

/* ---------- Media processing ---------- */

function getMediaTarget(el) {
  if (!el || !(el instanceof Element)) return null;
  const wrapper = el.closest(MEDIA_WRAPPER_SELECTOR);
  return wrapper && !isTooLarge(wrapper) ? wrapper : el;
}

function isLargeMedia(el) {
  if (!el || !(el instanceof Element)) return false;
  const r = el.getBoundingClientRect();
  return r && r.width >= 72 && r.height >= 72;
}

function collectSignals(mediaEl, target) {
  const parts = [];

  for (const el of [mediaEl, target].filter(Boolean)) {
    if (!(el instanceof Element)) continue;
    for (const attr of SIGNAL_ATTRS) {
      const v = el.getAttribute(attr);
      if (v) parts.push(v);
    }
  }

  const src = mediaEl.currentSrc || mediaEl.getAttribute("src");
  if (src) parts.push(src);

  const link = mediaEl.closest("a[href]");
  if (link) {
    for (const a of ["href", "aria-label", "title"]) {
      const v = link.getAttribute(a);
      if (v) parts.push(v);
    }
  }

  if (target instanceof Element) {
    const text = (target.innerText || "").trim();
    if (text) parts.push(text.slice(0, 900));
  }

  return parts.join(" ");
}

function isGoogleSearch() {
  return (
    location.hostname.includes("google.") &&
    location.pathname.startsWith("/search")
  );
}

function googleQuery() {
  try {
    return new URLSearchParams(location.search).get("q")?.trim() || "";
  } catch {
    return "";
  }
}

function processMedia(root) {
  if (!root || !matcher || (!settings.hideElements && !settings.redactMatches)) return;

  const els = root.querySelectorAll(MEDIA_SELECTOR);
  if (!els.length) return;

  const query = googleQuery();
  const queryMatched = isGoogleSearch() && hasMatch(query);
  const seen = new Map();

  for (const el of els) {
    if (!(el instanceof Element) || !el.isConnected) continue;
    const target = getMediaTarget(el);
    if (!target?.isConnected || target.closest(BLOCKED_SELECTOR)) continue;
    if (!seen.has(target)) seen.set(target, el);
  }

  for (const [target, mediaEl] of seen) {
    let matched = hasMatch(collectSignals(mediaEl, target));

    if (!matched && queryMatched) {
      matched =
        isLargeMedia(mediaEl) &&
        Boolean(target.closest(GOOGLE_CONTENT_SELECTOR)) &&
        !isTooLarge(target);
    }

    if (!matched) continue;

    if (settings.hideElements) {
      hideElement(target);
    } else if (settings.redactMatches) {
      redactElement(target);
    }
  }
}

function collectMediaEls(root, set) {
  if (!root || !(root instanceof Element)) return;
  if (root.matches(MEDIA_SELECTOR)) set.add(root);
  for (const m of root.querySelectorAll(MEDIA_SELECTOR)) set.add(m);
}

function findNearbyMedia(textNode, container) {
  const targets = new Set();
  const mediaEls = new Set();

  if (container) collectMediaEls(container, mediaEls);

  if (mediaEls.size === 0) {
    let anchor = textNode.parentElement;
    for (let d = 0; anchor && anchor !== document.body && d < 4; d++) {
      const parent = anchor.parentElement;
      if (!parent) break;
      for (const sib of parent.children) {
        if (sib === anchor || !(sib instanceof Element) || isTooLarge(sib)) continue;
        collectMediaEls(sib, mediaEls);
      }
      if (mediaEls.size > 0) break;
      anchor = parent;
    }
  }

  for (const m of mediaEls) {
    const t = getMediaTarget(m);
    if (t) targets.add(t);
  }

  return targets;
}

/* ---------- Main filter pass ---------- */

function applyFilters() {
  const root = document.body || document.documentElement;
  if (!root) return;

  applying = true;
  try {
    restoreHidden();
    restoreRedacted();
    if (!matcher || (!settings.hideElements && !settings.redactMatches)) return;
    walkText(root, processTextNode);
    processMedia(root);
  } finally {
    applying = false;
  }
}

function scheduleApply() {
  clearTimeout(timer);
  timer = setTimeout(() => {
    timer = null;
    applyFilters();
  }, 150);
}

/* ---------- Observer ---------- */

function startObserver() {
  const root = document.documentElement || document;

  new MutationObserver((mutations) => {
    if (applying) return;

    let dirty = false;
    for (const m of mutations) {
      if (m.type === "characterData" && m.target instanceof Text) {
        originalText.set(m.target, m.target.nodeValue || "");
        dirty = true;
      } else if (m.type === "childList") {
        for (const added of m.addedNodes) {
          walkText(added, (n) => originalText.set(n, n.nodeValue || ""));
        }
        if (m.addedNodes.length || m.removedNodes.length) dirty = true;
      }
    }

    if (dirty) scheduleApply();
  }).observe(root, { childList: true, subtree: true, characterData: true });
}

/* ---------- Init ---------- */

async function init() {
  try {
    let s = normalize(await storage.get(DEFAULTS));
    if (!hasUserConfig(s)) {
      const synced = normalize(await chrome.storage.sync.get(DEFAULTS));
      if (hasUserConfig(synced)) {
        await storage.set(synced);
        s = synced;
      }
    }
    applySettings(s);
  } catch {
    applySettings(DEFAULTS);
  }
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;

  const next = { ...settings };
  if ("blockedTerms" in changes) next.blockedTerms = changes.blockedTerms.newValue;
  if ("redactMatches" in changes) next.redactMatches = changes.redactMatches.newValue;
  if ("hideElements" in changes) next.hideElements = changes.hideElements.newValue;
  applySettings(next);
});

startObserver();
init();
