const DEFAULTS = {
  blockedTerms: [],
  redactMatches: true,
  hideElements: true,
};

const storage = chrome.storage.local;

const els = {
  terms: document.getElementById("blockedTerms"),
  redact: document.getElementById("redactMatches"),
  hide: document.getElementById("hideElements"),
  save: document.getElementById("saveBtn"),
  clear: document.getElementById("clearBtn"),
  status: document.getElementById("status"),
};

const controls = [els.terms, els.redact, els.hide, els.save, els.clear];

let saving = null;

/* ---------- Helpers ---------- */

function setStatus(message, isError = false) {
  els.status.textContent = message;
  els.status.classList.toggle("status--error", isError);
}

function setBusy(busy) {
  for (const el of controls) el.disabled = busy;
}

function dedupeLines(raw) {
  const terms = [];
  const seen = new Set();

  for (const line of raw.split(/\r?\n/)) {
    const term = line.trim();
    if (!term) continue;

    const key = term.toLowerCase();
    if (seen.has(key)) continue;

    seen.add(key);
    terms.push(term);
  }

  return terms;
}

function normalizeTerms(terms) {
  if (!Array.isArray(terms)) return [];

  const out = [];
  const seen = new Set();

  for (const v of terms) {
    const term = String(v).trim();
    if (!term) continue;

    const key = term.toLowerCase();
    if (seen.has(key)) continue;

    seen.add(key);
    out.push(term);
  }

  return out;
}

function normalize(raw) {
  return {
    blockedTerms: normalizeTerms(raw.blockedTerms),
    redactMatches:
      typeof raw.redactMatches === "boolean"
        ? raw.redactMatches
        : DEFAULTS.redactMatches,
    hideElements:
      typeof raw.hideElements === "boolean"
        ? raw.hideElements
        : DEFAULTS.hideElements,
  };
}

function hasUserConfig(s) {
  return (
    s.blockedTerms.length > 0 ||
    s.redactMatches !== DEFAULTS.redactMatches ||
    s.hideElements !== DEFAULTS.hideElements
  );
}

/* ---------- Load / Save ---------- */

async function loadSettings() {
  setBusy(true);

  try {
    let settings = normalize(await storage.get(DEFAULTS));

    if (!hasUserConfig(settings)) {
      const synced = normalize(await chrome.storage.sync.get(DEFAULTS));
      if (hasUserConfig(synced)) {
        await storage.set(synced);
        settings = synced;
      }
    }

    els.terms.value = settings.blockedTerms.join("\n");
    els.redact.checked = settings.redactMatches;
    els.hide.checked = settings.hideElements;
  } catch {
    setStatus("Could not load settings.", true);
  } finally {
    setBusy(false);
  }
}

async function saveSettings() {
  if (saving) return saving;

  const blockedTerms = dedupeLines(els.terms.value);
  const payload = {
    blockedTerms,
    redactMatches: els.redact.checked,
    hideElements: els.hide.checked,
  };

  setStatus("Saving\u2026");
  setBusy(true);

  saving = (async () => {
    try {
      await storage.set(payload);
      els.terms.value = blockedTerms.join("\n");

      const n = blockedTerms.length;
      setStatus(n ? `Saved ${n} term${n === 1 ? "" : "s"}.` : "All terms cleared.");
    } catch {
      setStatus("Could not save.", true);
    } finally {
      saving = null;
      setBusy(false);
    }
  })();

  return saving;
}

function clearAll() {
  els.terms.value = "";
  return saveSettings();
}

/* ---------- Events ---------- */

els.save.addEventListener("click", saveSettings);
els.clear.addEventListener("click", clearAll);
els.redact.addEventListener("change", saveSettings);
els.hide.addEventListener("change", saveSettings);

loadSettings();
